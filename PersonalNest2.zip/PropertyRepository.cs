﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersonalNest2
{
    using global::PersonalNest;
    using System;
    using System.Collections.Generic;
    using System.Data.SqlClient;

    namespace PersonalNest
    {
        public class PropertyRepository
        {
            private readonly string _connectionString;

            public PropertyRepository(string connectionString)
            {
                _connectionString = connectionString;
            }

            public List<Property> GetAll()
            {
                var properties = new List<Property>();

                using (var connection = new SqlConnection(_connectionString))
                {
                    connection.Open();

                    var query = "SELECT * FROM [dbo].[property]";

                    using (var command = new SqlCommand(query, connection))
                    {
                        using (var reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                var property = new Property
                                {
                                    Id = reader.GetInt32(reader.GetOrdinal("id")),
                                    OwnerId = reader.GetInt32(reader.GetOrdinal("owner_id")),
                                    Name = reader.GetString(reader.GetOrdinal("name")),
                                    Address = reader.GetString(reader.GetOrdinal("address")),
                                    City = reader.GetString(reader.GetOrdinal("city")),
                                    State = reader.GetString(reader.GetOrdinal("state")),
                                    Country = reader.GetString(reader.GetOrdinal("country")),
                                    PropertyType = reader.GetString(reader.GetOrdinal("property_type")),
                                    NumRooms = reader.GetInt32(reader.GetOrdinal("num_rooms")),
                                    HasPool = reader.GetBoolean(reader.GetOrdinal("has_pool")),
                                    HasBeach = reader.GetBoolean(reader.GetOrdinal("has_beach")),
                                    HasGarden = reader.GetBoolean(reader.GetOrdinal("has_garden")),
                                    HasFence = reader.GetBoolean(reader.GetOrdinal("has_fence")),
                                    PossessionDate = reader.GetDateTime(reader.GetOrdinal("possession_date")),
                                    Price = reader.GetDecimal(reader.GetOrdinal("price"))
                                };

                                properties.Add(property);
                            }
                        }
                    }
                }

                return properties;
            }

            public Property GetPropertyByName(string propertyName)
            {
                return GetAll().SingleOrDefault(p => p.Name == propertyName);
            }

            public Property GetPropertyById(int propertyId)
            {
                return GetAll().SingleOrDefault(p => p.Id == propertyId);
            }

            public Property GetById(int id)
            {
                using (var connection = new SqlConnection(_connectionString))
                {
                    connection.Open();

                    var query = "SELECT * FROM [dbo].[property] WHERE [id] = @id";

                    using (var command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@id", id);

                        using (var reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                return new Property
                                {
                                    Id = reader.GetInt32(reader.GetOrdinal("id")),
                                    OwnerId = reader.GetInt32(reader.GetOrdinal("owner_id")),
                                    Name = reader.GetString(reader.GetOrdinal("name")),
                                    Address = reader.GetString(reader.GetOrdinal("address")),
                                    City = reader.GetString(reader.GetOrdinal("city")),
                                    State = reader.GetString(reader.GetOrdinal("state")),
                                    Country = reader.GetString(reader.GetOrdinal("country")),
                                    PropertyType = reader.GetString(reader.GetOrdinal("property_type")),
                                    NumRooms = reader.GetInt32(reader.GetOrdinal("num_rooms")),
                                    HasPool = reader.GetBoolean(reader.GetOrdinal("has_pool")),
                                    HasBeach = reader.GetBoolean(reader.GetOrdinal("has_beach")),
                                    HasGarden = reader.GetBoolean(reader.GetOrdinal("has_garden")),
                                    HasFence = reader.GetBoolean(reader.GetOrdinal("has_fence")),
                                    PossessionDate = reader.GetDateTime(reader.GetOrdinal("possession_date")),
                                    Price = reader.GetDecimal(reader.GetOrdinal("price"))
                                };
                            }
                        }
                    }
                }

                return null;
            }
            public Property Create(Property property)
            {
                using (var connection = new SqlConnection(_connectionString))
                {
                    connection.Open();

                    var command = new SqlCommand(
                        @"INSERT INTO [dbo].[property] 
            ([owner_id], [name], [address], [city], [state], [country], [property_type], [num_rooms], [has_pool], [has_beach], [has_garden], [has_fence], [possession_date], [price])
            VALUES (@owner_id, @name, @address, @city, @state, @country, @property_type, @num_rooms, @has_pool, @has_beach, @has_garden, @has_fence, @possession_date, @price);
            SELECT CAST(SCOPE_IDENTITY() as int)",
                        connection);

                    command.Parameters.AddWithValue("@owner_id", property.OwnerId);
                    command.Parameters.AddWithValue("@name", property.Name);
                    command.Parameters.AddWithValue("@address", property.Address);
                    command.Parameters.AddWithValue("@city", property.City);
                    command.Parameters.AddWithValue("@state", property.State);
                    command.Parameters.AddWithValue("@country", property.Country);
                    command.Parameters.AddWithValue("@property_type", property.PropertyType);
                    command.Parameters.AddWithValue("@num_rooms", property.NumRooms);
                    command.Parameters.AddWithValue("@has_pool", property.HasPool);
                    command.Parameters.AddWithValue("@has_beach", property.HasBeach);
                    command.Parameters.AddWithValue("@has_garden", property.HasGarden);
                    command.Parameters.AddWithValue("@has_fence", property.HasFence);
                    command.Parameters.AddWithValue("@possession_date", property.PossessionDate);
                    command.Parameters.AddWithValue("@price", property.Price);

                    var newId = (int)command.ExecuteScalar();

                    property.Id = newId;
                }

                return property;
            }

            public List<Property> GetTopProperties()
            {
                List<Property> topProperties = new List<Property>();

                using (var connection = new SqlConnection(_connectionString))
                {
                    connection.Open();

                    // get top-rated properties based on different categories
                    string query = @"
                SELECT *
                FROM [dbo].[property]
                WHERE [num_rooms] >= 2 AND [has_pool] = 1 AND [has_beach] = 1
                ORDER BY [price] DESC
                OFFSET 0 ROWS
                FETCH NEXT 10 ROWS ONLY";

                    using (var command = new SqlCommand(query, connection))
                    {
                        using (var reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                var property = new Property()
                                {
                                    Id = (int)reader["id"],
                                    OwnerId = (int)reader["owner_id"],
                                    Name = (string)reader["name"],
                                    Address = (string)reader["address"],
                                    City = (string)reader["city"],
                                    State = (string)reader["state"],
                                    Country = (string)reader["country"],
                                    PropertyType = (string)reader["property_type"],
                                    NumRooms = (int)reader["num_rooms"],
                                    HasPool = (bool)reader["has_pool"],
                                    HasBeach = (bool)reader["has_beach"],
                                    HasGarden = (bool)reader["has_garden"],
                                    HasFence = (bool)reader["has_fence"],
                                    PossessionDate = (DateTime)reader["possession_date"],
                                    Price = (decimal)reader["price"]
                                };

                                topProperties.Add(property);
                            }
                        }
                    }
                }

                return topProperties;
            }

            public List<Property> SearchProperties(string city, int minRooms, decimal maxPrice)
            {
                List<Property> properties = new List<Property>();

                // Set up ADO.NET objects
                using (SqlConnection connection = new SqlConnection(_connectionString))
                {
                    SqlCommand command = new SqlCommand();
                    command.Connection = connection;

                    // Construct the SQL query
                    string query = "SELECT * FROM [dbo].[property] WHERE [city] = @city AND [num_rooms] >= @minRooms AND [price] <= @maxPrice";
                    command.CommandText = query;

                    // Add parameters to the SQL query
                    command.Parameters.AddWithValue("@city", city);
                    command.Parameters.AddWithValue("@minRooms", minRooms);
                    command.Parameters.AddWithValue("@maxPrice", maxPrice);

                    // Execute the query
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    // Read the results and construct Property objects
                    while (reader.Read())
                    {
                        Property property = new Property();
                        property.Id = Convert.ToInt32(reader["id"]);
                        property.OwnerId = Convert.ToInt32(reader["owner_id"]);
                        property.Name = reader["name"].ToString();
                        property.Address = reader["address"].ToString();
                        property.City = reader["city"].ToString();
                        property.State = reader["state"].ToString();
                        property.Country = reader["country"].ToString();
                        property.PropertyType = reader["property_type"].ToString();
                        property.NumRooms = Convert.ToInt32(reader["num_rooms"]);
                        property.HasPool = Convert.ToBoolean(reader["has_pool"]);
                        property.HasBeach = Convert.ToBoolean(reader["has_beach"]);
                        property.HasGarden = Convert.ToBoolean(reader["has_garden"]);
                        property.HasFence = Convert.ToBoolean(reader["has_fence"]);
                        property.PossessionDate = Convert.ToDateTime(reader["possession_date"]);
                        property.Price = Convert.ToDecimal(reader["price"]);
                        properties.Add(property);
                    }

                    reader.Close();
                }

                return properties;
            }

            public List<Property> GetPropertiesByOwnerId(int ownerId)
            {
                List<Property> properties = new List<Property>();

                try
                {
                    using (SqlConnection conn = new SqlConnection(_connectionString))
                    {
                        conn.Open();
                        string query = "SELECT * FROM property WHERE owner_id = @OwnerId";
                        SqlCommand cmd = new SqlCommand(query, conn);
                        cmd.Parameters.AddWithValue("@OwnerId", ownerId);
                        SqlDataReader reader = cmd.ExecuteReader();

                        while (reader.Read())
                        {
                            Property property = new Property();
                            property.Id = Convert.ToInt32(reader["id"]);
                            property.OwnerId = Convert.ToInt32(reader["owner_id"]);
                            property.Name = Convert.ToString(reader["name"]);
                            property.Address = Convert.ToString(reader["address"]);
                            property.City = Convert.ToString(reader["city"]);
                            property.State = Convert.ToString(reader["state"]);
                            property.Country = Convert.ToString(reader["country"]);
                            property.PropertyType = Convert.ToString(reader["property_type"]);
                            property.NumRooms = Convert.ToInt32(reader["num_rooms"]);
                            property.HasPool = Convert.ToBoolean(reader["has_pool"]);
                            property.HasBeach = Convert.ToBoolean(reader["has_beach"]);
                            property.HasGarden = Convert.ToBoolean(reader["has_garden"]);
                            property.HasFence = Convert.ToBoolean(reader["has_fence"]);
                            property.PossessionDate = Convert.ToDateTime(reader["possession_date"]);
                            property.Price = Convert.ToDecimal(reader["price"]);

                            properties.Add(property);
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("An error occurred while getting properties by owner id: " + ex.Message);
                }

                return properties;
            }

            public List<Property> GetPropertiesSortedByPrice(bool ascending)
            {
                string sortOrder = ascending ? "ASC" : "DESC";

                string query = $"SELECT * FROM [dbo].[Property] ORDER BY [price] {sortOrder}";

                List<Property> properties = new List<Property>();

                using (SqlConnection connection = new SqlConnection(_connectionString))
                {
                    SqlCommand command = new SqlCommand(query, connection);

                    connection.Open();

                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        Property property = new Property()
                        {
                            Id = Convert.ToInt32(reader["id"]),
                            OwnerId = Convert.ToInt32(reader["owner_id"]),
                            Name = reader["name"].ToString(),
                            Address = reader["address"].ToString(),
                            City = reader["city"].ToString(),
                            State = reader["state"].ToString(),
                            Country = reader["country"].ToString(),
                            PropertyType = reader["property_type"].ToString(),
                            NumRooms = Convert.ToInt32(reader["num_rooms"]),
                            HasPool = Convert.ToBoolean(reader["has_pool"]),
                            HasBeach = Convert.ToBoolean(reader["has_beach"]),
                            HasGarden = Convert.ToBoolean(reader["has_garden"]),
                            HasFence = Convert.ToBoolean(reader["has_fence"]),
                            PossessionDate = Convert.ToDateTime(reader["possession_date"]),
                            Price = Convert.ToDecimal(reader["price"])
                        };

                        properties.Add(property);
                    }
                }

                return properties;
            }

            public void Update(Property propertyToUpdate)
            {
                using (SqlConnection connection = new SqlConnection(_connectionString))
                {
                    string query = "UPDATE Property " +
                                   "SET Name = @Name, Address = @Address, City = @City, State = @State, " +
                                   "Country = @Country, Property_Type = @PropertyType, Num_Rooms = @NumRooms, " +
                                   "Has_Pool = @HasPool, Has_Beach = @HasBeach, Has_Garden = @HasGarden, " +
                                   "Has_Fence = @HasFence, Possession_Date = @PossessionDate, Price = @Price " +
                                   "WHERE Id = @Id AND Owner_Id = @OwnerId";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Id", propertyToUpdate.Id);
                        command.Parameters.AddWithValue("@OwnerId", propertyToUpdate.OwnerId);
                        command.Parameters.AddWithValue("@Name", propertyToUpdate.Name);
                        command.Parameters.AddWithValue("@Address", propertyToUpdate.Address);
                        command.Parameters.AddWithValue("@City", propertyToUpdate.City);
                        command.Parameters.AddWithValue("@State", propertyToUpdate.State);
                        command.Parameters.AddWithValue("@Country", propertyToUpdate.Country);
                        command.Parameters.AddWithValue("@PropertyType", propertyToUpdate.PropertyType);
                        command.Parameters.AddWithValue("@NumRooms", propertyToUpdate.NumRooms);
                        command.Parameters.AddWithValue("@HasPool", propertyToUpdate.HasPool);
                        command.Parameters.AddWithValue("@HasBeach", propertyToUpdate.HasBeach);
                        command.Parameters.AddWithValue("@HasGarden", propertyToUpdate.HasGarden);
                        command.Parameters.AddWithValue("@HasFence", propertyToUpdate.HasFence);
                        command.Parameters.AddWithValue("@PossessionDate", propertyToUpdate.PossessionDate);
                        command.Parameters.AddWithValue("@Price", propertyToUpdate.Price);

                        connection.Open();
                        int rowsAffected = command.ExecuteNonQuery();
                        if (rowsAffected == 0)
                        {
                            throw new ArgumentException("Property not found or not owned by the specified user.");
                        }
                    }
                }
            }


            public void DeleteProperty(int id, int ownerId)
            {
                using (SqlConnection connection = new SqlConnection(_connectionString))
                {
                    connection.Open();
                    string query = "DELETE FROM Properties WHERE Id = @Id AND OwnerId = @OwnerId";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@Id", id);
                    command.Parameters.AddWithValue("@OwnerId", ownerId);

                    int rowsAffected = command.ExecuteNonQuery();
                    if (rowsAffected == 0)
                    {
                        throw new Exception("No rows deleted. Property not found or you are not the owner.");
                    }
                }
            }

        }
    }
}
