﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersonalNest
{
    public class UserRepository
    {
        private readonly string _connectionString;

        public UserRepository(string connectionString)
        {
            _connectionString = connectionString;
        }

        public User Register(string username, string password, int usertype)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();

                // Check if the username or email already exists
                var command = new SqlCommand("SELECT COUNT(*) FROM Users WHERE Username = @Username ", connection);
                command.Parameters.AddWithValue("@Username", username);

                var count = (int)command.ExecuteScalar();

                if (count > 0)
                {
                    throw new ApplicationException("The username or email already exists.");
                }

                // Insert the new user into the database
                command = new SqlCommand("INSERT INTO Users (Username, Password,usertype) VALUES (@Username, @Password,@usertype); SELECT SCOPE_IDENTITY()", connection);
                command.Parameters.AddWithValue("@Username", username);
                command.Parameters.AddWithValue("@Password", password);
                command.Parameters.AddWithValue("@usertype", usertype);

                var userId = command.ExecuteScalar();

                return new User { UserId = Convert.ToInt32(userId), Username = username };
            }
        }

        public User Login(string username, string password)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();

                // Check if the user with the given username and password exists
                var command = new SqlCommand("SELECT userId  FROM Users WHERE Username = @Username AND Password = @Password", connection);
                command.Parameters.AddWithValue("@Username", username);
                command.Parameters.AddWithValue("@Password", password);
                var user = new User();


                using (var reader = command.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        int userId = reader.GetInt32(0);
                        user = GetUser(userId);
                        return user;
                    }
                    else
                    {
                        throw new ApplicationException("Invalid username or password.");
                    }
                }
               
            }
        }

        public User GetUser(int userId)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();

                // Check if the user with the given username and password exists
                var command = new SqlCommand("SELECT *  FROM Users WHERE userId = @userId", connection);
                command.Parameters.AddWithValue("@userId", userId);
                var user = new User();
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        user = new User
                        {
                            UserId = reader.GetInt32(reader.GetOrdinal("UserId")),
                            Username = reader.GetString(reader.GetOrdinal("Username")),
                            UserType = reader.GetInt32(reader.GetOrdinal("UserType"))
                        };

                    }
                    return user;
                }
               
            }
        }
        public void Logout(User user)
        {
            // Set the user's session token to null to indicate that they are logged out
            user.SessionToken = null;

            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();

                // Update the user's session token in the database
                using (var command = new SqlCommand("UPDATE Users SET SessionToken = @sessionToken WHERE UserId = @userId", connection))
                {
                    command.Parameters.AddWithValue("@sessionToken", DBNull.Value);
                    command.Parameters.AddWithValue("@userId", user.UserId);
                    command.ExecuteNonQuery();
                }
            }
        }

    }

}
