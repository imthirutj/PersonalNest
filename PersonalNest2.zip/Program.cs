﻿using PersonalNest;
using PersonalNest2.PersonalNest;
using System;
using System.Collections.Generic;
using System.Linq;

namespace PersonalNest2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string connectionString = "Data Source=THIRU_XIOMI\\SQLEXPRESS;Initial Catalog=PersonalNest;Integrated Security=True;Connect Timeout=30;Encrypt=False;";
            var userRepository = new UserRepository(connectionString);
            var propertyRepository = new PropertyRepository(connectionString);

            Console.Write("Enter options: \n 1.Register \n 2.Login");
            int option = Convert.ToInt32(Console.ReadLine());

            if (option == 1)
            {
                // Prompt user for input
                Console.Write("Enter username: ");
                string username = Console.ReadLine();

                Console.Write("Enter password: ");
                string password = Console.ReadLine();

                Console.Write("Enter UserType:\n1.User \n2.Seller ");
                int userType = Convert.ToInt32(Console.ReadLine());

                // Register a new user with input from user
                var newUser = userRepository.Register(username, password, userType);

                Console.WriteLine($"User {newUser.Username} registered successfully!");
            }
            else if (option == 2)
            {
                // Prompt user for input
                Console.Write("Enter username: ");
                string username = Console.ReadLine();

                Console.Write("Enter password: ");
                string password = Console.ReadLine();

                // Login the user with input from user
                var user = userRepository.Login(username, password);
                Console.WriteLine($"User {user.Username} login successfully!");

                if (user.UserType ==2)
                {
                    Console.WriteLine("Welcome, seller!");
                    Console.WriteLine("1. Create property");
                    Console.WriteLine("2. View properties");
                     Console.WriteLine("3. Update property");
                     Console.WriteLine("4. Delete property");

                    int userTypeOption = Convert.ToInt32(Console.ReadLine());
                    if (userTypeOption == 1)
                    {
                        // Prompt user for input and create a new property
                        Console.Write("Enter property name: ");
                        string propertyName = Console.ReadLine();

                        Console.Write("Enter property address: ");
                        string propertyAddress = Console.ReadLine();

                        Console.Write("Enter property city: ");
                        string propertyCity = Console.ReadLine();

                        Console.Write("Enter property state: ");
                        string propertyState = Console.ReadLine();

                        Console.Write("Enter property country: ");
                        string propertyCountry = Console.ReadLine();

                        Console.Write("Enter property type: ");
                        string propertyType = Console.ReadLine();

                        Console.Write("Enter number of rooms: ");
                        int numRooms = Convert.ToInt32(Console.ReadLine());

                        Console.Write("Does the property have a pool? (Y/N) ");
                        bool hasPool = Console.ReadLine().ToUpper() == "Y";

                        Console.Write("Does the property have a beach? (Y/N) ");
                        bool hasBeach = Console.ReadLine().ToUpper() == "Y";

                        Console.Write("Does the property have a garden? (Y/N) ");
                        bool hasGarden = Console.ReadLine().ToUpper() == "Y";

                        Console.Write("Does the property have a fence? (Y/N) ");
                        bool hasFence = Console.ReadLine().ToUpper() == "Y";

                        Console.Write("Enter possession date (yyyy-mm-dd): ");
                        DateTime possessionDate = Convert.ToDateTime(Console.ReadLine());

                        Console.Write("Enter property price: ");
                        decimal price = Convert.ToDecimal(Console.ReadLine());

                        Property newProperty = new Property
                        {
                            OwnerId = user.UserId,
                            Name = propertyName,
                            Address = propertyAddress,
                            City = propertyCity,
                            State = propertyState,
                            Country = propertyCountry,
                            PropertyType = propertyType,
                            NumRooms = numRooms,
                            HasPool = hasPool,
                            HasBeach = hasBeach,
                            HasGarden = hasGarden,
                            HasFence = hasFence,
                            PossessionDate = possessionDate,
                            Price = price
                        };

                        propertyRepository.Create(newProperty);
                        Console.WriteLine($"Property {newProperty.Name} created successfully!");
                    }
                    else if (userTypeOption == 2)
                    {
                        var sellerProperties = propertyRepository.GetPropertiesByOwnerId(user.UserId);

                        Console.WriteLine($"Found {sellerProperties.Count()} properties for seller {user.Username}:");
                        foreach (var property in sellerProperties)
                        {
                            Console.WriteLine($"Name: {property.Name}, City: {property.City}, Price: {property.Price}");
                        }
                    }
                    else if (userTypeOption == 3)
                    {
                        // Prompt user for input and update a property
                        Console.Write("Enter the name of the property to update: ");
                        string propertyName = Console.ReadLine();

                        // Get the property by name and check if it belongs to the user
                        var propertyToUpdate = propertyRepository.GetPropertyByName(propertyName);
                        if (propertyToUpdate == null)
                        {
                            Console.WriteLine($"No property found with name {propertyName}.");
                        }
                        else if (propertyToUpdate.OwnerId != user.UserId)
                        {
                            Console.WriteLine($"The property {propertyName} does not belong to you.");
                        }
                        else
                        {
                            Console.WriteLine("Enter the new information for the property:");

                            Console.Write("Enter property address: ");
                            propertyToUpdate.Address = Console.ReadLine();

                            Console.Write("Enter property city: ");
                            propertyToUpdate.City = Console.ReadLine();

                            Console.Write("Enter property state: ");
                            propertyToUpdate.State = Console.ReadLine();

                            Console.Write("Enter property country: ");
                            propertyToUpdate.Country = Console.ReadLine();

                            Console.Write("Enter property type: ");
                            propertyToUpdate.PropertyType = Console.ReadLine();

                            Console.Write("Enter number of rooms: ");
                            propertyToUpdate.NumRooms = Convert.ToInt32(Console.ReadLine());

                            Console.Write("Does the property have a pool? (Y/N) ");
                            propertyToUpdate.HasPool = Console.ReadLine().ToUpper() == "Y";

                            Console.Write("Does the property have a beach? (Y/N) ");
                            propertyToUpdate.HasBeach = Console.ReadLine().ToUpper() == "Y";

                            Console.Write("Does the property have a garden? (Y/N) ");
                            propertyToUpdate.HasGarden = Console.ReadLine().ToUpper() == "Y";

                            Console.Write("Does the property have a fence? (Y/N) ");
                            propertyToUpdate.HasFence = Console.ReadLine().ToUpper() == "Y";

                            Console.Write("Enter possession date (yyyy-mm-dd): ");
                            propertyToUpdate.PossessionDate = Convert.ToDateTime(Console.ReadLine());

                            Console.Write("Enter property price: ");
                            propertyToUpdate.Price = Convert.ToDecimal(Console.ReadLine());

                            propertyRepository.Update(propertyToUpdate);
                            Console.WriteLine($"Property {propertyName} updated successfully!");
                        }
                    }
                    else if (userTypeOption == 4)
                    {
                        Console.Write("Enter the ID of the property to delete: ");
                        int propertyId = Convert.ToInt32(Console.ReadLine());

                        Property propertyToDelete = propertyRepository.GetPropertyById(propertyId);

                        if (propertyToDelete == null || propertyToDelete.OwnerId != user.UserId)
                        {
                            Console.WriteLine("Property not found or you do not have permission to delete it.");
                        }
                        else
                        {
                            propertyRepository.DeleteProperty(propertyId, user.UserId);
                            Console.WriteLine($"Property {propertyToDelete.Name} deleted successfully!");
                        }

                    }
                }
                else
                {
                    Console.WriteLine("Welcome, user!");
                    Console.WriteLine("1. Search properties");
                    Console.WriteLine("2. View top-rated properties");
                    Console.WriteLine("3. Sort properties By Price");

                    int PropertyOption = Convert.ToInt32(Console.ReadLine());

                   

                  


                    if (PropertyOption == 1)
                    {
                        // Search properties based on different criteria
                        Console.WriteLine("\nSearch properties based on different criteria:");
                        Console.WriteLine("----------------------------------------------");
                        Console.Write("Enter the city name to search properties: ");
                        string city = Console.ReadLine();

                        Console.Write("Enter the minimum number of rooms: ");
                        int minRooms = Convert.ToInt32(Console.ReadLine());

                        Console.Write("Enter the maximum price: ");
                        decimal maxPrice = Convert.ToDecimal(Console.ReadLine());

                        var searchResults = propertyRepository.SearchProperties(city, minRooms, maxPrice);
                        Console.WriteLine($"Found {searchResults.Count()} properties matching the search criteria:");
                        foreach (var property in searchResults)
                        {
                            Console.WriteLine($"Name: {property.Name}, City: {property.City}, Price: {property.Price}");
                        }
                    }
                    else if (PropertyOption == 2)
                    {
                        // Display top-rated properties in different categories
                        Console.WriteLine("\nTop-rated properties in different categories:");
                        Console.WriteLine("-------------------------------------------------");
                        var topProperties = propertyRepository.GetTopProperties();
                        foreach (var property in topProperties)
                        {
                            Console.WriteLine($"Category: {property.PropertyType}, Name: {property.Name}");
                        }
                    }
                else if(PropertyOption == 3)
                    {

                        Console.Write("Sort properties by price (ascending/descending)? ");
                        string sortOrderInput = Console.ReadLine();

                        bool ascending = sortOrderInput.ToLower() == "ascending";

                        List<Property> sortedProperties = propertyRepository.GetPropertiesSortedByPrice(ascending);

                        foreach (Property property in sortedProperties)
                        {
                            Console.WriteLine($"Name: {property.Name}, Price: {property.Price}");
                        }
                    }
                
                }

               

                // Logout the user
                userRepository.Logout(user);
                Console.WriteLine($"User {user.Username} logout successfully!");
            }
            Console.ReadLine();
        }
    }
}
