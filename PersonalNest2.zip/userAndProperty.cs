﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersonalNest
{
    public class User
    {
        public int UserId { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public int UserType { get; set; }
        public string SessionToken { get; set; }    
    }

    public class Property
    {
        public int Id { get; set; }
        public int OwnerId { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Country { get; set; }
        public string PropertyType { get; set; }
        public int NumRooms { get; set; }
        public bool HasPool { get; set; }
        public bool HasBeach { get; set; }
        public bool HasGarden { get; set; }
        public bool HasFence { get; set; }
        public DateTime PossessionDate { get; set; }
        public decimal Price { get; set; }
    }


}
